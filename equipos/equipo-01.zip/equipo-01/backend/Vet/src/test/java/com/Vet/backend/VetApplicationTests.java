package com.Vet.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VetApplicationTests {

    @Test
    void contextLoads() {
    }

}
