package com.veterinaria_xime.backend.controller;

import com.veterinaria_xime.backend.model.Mascota;
import com.veterinaria_xime.backend.model.Producto;
import com.veterinaria_xime.backend.service.ProductoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/duenos")
public class ProductoController {
    private final ProductoService productoService;

    public ProductoController(ProductoService productoService){
        this.productoService = productoService;
    }

    @GetMapping
    public List<Producto> listar(){
        return productoService.listar();
    }

    @GetMapping
    public Producto buscarPorId(@PathVariable Long id){
        return productoService.buscarPorId(id);
    }

    @PostMapping
    public Producto guardar(@RequestBody Mascota producto) {
        return productoService.guardar(producto);
    }

}

