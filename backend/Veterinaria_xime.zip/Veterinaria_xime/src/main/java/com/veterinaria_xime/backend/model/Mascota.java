package com.veterinaria_xime.backend.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "mascotas" , schema = "public")
public class Mascota {
    @Id
    @Column(name = "id_mascota")
    private Long id;
    private String nombre;
    private String id_dueno;
    private String id_raza;
    private String fecha_nacimiento;

    public Mascota() {
    }

    public class Mascotas {
        private Long id;
        private String nombre;
        private String id_dueno;
        private String id_raza;
        private String fecha_nacimiento;


        public Mascotas(Long id, String nombre, String id_dueno, String id_raza, String fecha_nacimiento) {
            this.id = id;
            this.nombre = nombre;
            this.id_dueno = id_dueno;
            this.id_raza = id_raza;
            this.fecha_nacimiento = fecha_nacimiento;
        }

        public Long getId() {
            return id;
        }

        public String getNombre() {
            return nombre;
        }

        public String getId_duenoDueno() {
            return id_dueno;
        }

        public String getId_Raza() {
            return id_raza;
        }

        public String getFecha_nacimiento() {
            return fecha_nacimiento;
        }
    }
}


